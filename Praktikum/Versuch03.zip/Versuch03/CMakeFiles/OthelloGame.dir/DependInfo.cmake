
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/matthewstark/cpp_practices/Praktikum/Versuch03/othello.cpp" "CMakeFiles/OthelloGame.dir/othello.cpp.o" "gcc" "CMakeFiles/OthelloGame.dir/othello.cpp.o.d"
  "/Users/matthewstark/cpp_practices/Praktikum/Versuch03/othelloKI.cpp" "CMakeFiles/OthelloGame.dir/othelloKI.cpp.o" "gcc" "CMakeFiles/OthelloGame.dir/othelloKI.cpp.o.d"
  "/Users/matthewstark/cpp_practices/Praktikum/Versuch03/test.cpp" "CMakeFiles/OthelloGame.dir/test.cpp.o" "gcc" "CMakeFiles/OthelloGame.dir/test.cpp.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
